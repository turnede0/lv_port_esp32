# Contributing to LVGL

Thank you for considering contributing to LVGL.

For a detailed description of contribution opportunities, please visit the [Contributing](https://docs.lvgl.io/latest/en/html/contributing/index.html) section of the documentation.
