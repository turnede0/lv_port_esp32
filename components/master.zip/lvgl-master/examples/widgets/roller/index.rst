
Simple Roller 
""""""""""""""""

.. lv_example:: widgets/roller/lv_example_roller_1
  :language: c
  
Styling the roller
""""""""""""""""""

.. lv_example:: widgets/roller/lv_example_roller_2
  :language: c

add fade mask to roller
"""""""""""""""""""""""

.. lv_example:: widgets/roller/lv_example_roller_3
  :language: c

